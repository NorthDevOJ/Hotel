
package controlador;


import vista.PantallaDeCarga;


public class Principal {
    
    public static void main(String[] args) {
        
        PantallaDeCarga inicio = new PantallaDeCarga();
        inicio.CargarScreen(inicio);
    }
}
